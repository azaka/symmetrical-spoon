Track0.mp3 and Track1.mp3 have to be in this folder for the music options to be available.
These file must not contain any ID3v2 tag, or they won't play on the PSP.
