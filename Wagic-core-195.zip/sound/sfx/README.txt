you can put wave files in this folder.
the name of the file can be any ability (flying.wav, trample.wav, lifelink.wav, ...)
or a supertype (artifact.wav, sorcery.wav, creature.wav...)
or a type (human.wav, dragon.wav...)

The game will automatically use the files ( if they are available) when a card comes into play.

Special files are mana.wav and graveyard.wav