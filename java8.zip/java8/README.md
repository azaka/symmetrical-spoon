This is openjdk 8 build for termux you can use it follow the instruction below
do not post this to any website or github thread!
It's better that you use Termux-Rootfs provided by @xeffyr on github(google it)
first extract this file in any folder and copy gnulib and java-8-jdk folder
follow the commands:-
cp -r gnulib $PREFIX/share/ && cp -r java-8-jdk $PREFIX/share/
now go to bin folder and paste that command:-
cp * $PREFIX/bin
restart termux and tyoe java or java -version.
enjoy!
