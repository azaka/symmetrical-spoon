#!usr/bin/env python
import pygame
from   pygame.locals import *
from   constant      import *
from   utility       import *

class Reader:
    def __init__(self):
        #Parser
        self.new_stack()
        self.data = copy(DATA)

    def new_stack(self, keys=[], syms=[]):
        #Resets dict key and symbol stacks
        self.keys = keys[:]
        self.syms = syms[:]

    def new_data(self, data=DATA):
        #Resets data
        self.new_stack()
        self.data = copy(data)

    def output_data(self):
        #Returns all data
        return self.data

    def get_data(self, line):
        #Interprets script line
        block = get_block(self.keys, self.syms, line)
        if not block:
            key  = get_assigns(line)
            vals = get_inputs(line)
            update_dict(self.data, self.keys, key, vals)

    
    def read(self, filename):
        #Parses given script file
        self.new_stack()

        #Open filename and parse contents
        with open(filename, 'r') as f:
            lines = clean(f.readlines())
            for line in lines:
                self.get_data(line)
                
