#!usr/bin/env python
import pygame, os
from   pygame.locals import *
from   constant      import *
from   utility       import *
from   reader        import *
from   level         import *
from   interface     import *

#Center screen
os.environ['SDL_VIDEO_CENTERED'] = '1'

#Main method wrapper

STATE_MAIN  = 'main'
STATE_LEVEL = 'level'

class Main:
    def __init__(self):
        pygame.init()
        self.init_renderer()
        self.init_objects()

    def init_renderer(self):
        #Initializes rendering objects
        self.window    = init_display()
        self.screen    = make_surface(MW*TW, MH*TH)
        self.interface = Interface()
        self.rect      = self.screen.get_rect(topleft=SCREENPOS)
        self.delta     = self.rect.topleft
        self.clock     = pygame.time.Clock()

    def init_objects(self):
        #Initializes utility objects
        self.parser = Reader()
        for path in [FILE_MAPS,FILE_UNIT,FILE_SAVE]:
            p = get_path(DIR_DATA, path)
            self.parser.read(p)

        self.data = self.parser.output_data()

    def load_level(self, key='000'):
        #Loads a level
        keys = ['hero','knight','dragon','horse']
        self.level = Level(self.data[KEY_MAPS][key])
        load_units(self.level, self.data, True, *keys)
        load_units(self.level, self.data, False, *keys)

    def render(self):
        #Renders self to screen
        self.screen.fill((0,255,255))
        self.level.render(self.screen)
        
        #Blit temporary screen to actual display
        self.window.blit(self.screen, self.rect)
        self.interface.render(self.window)
        
        pygame.display.flip()

    def main(self):
        #Main method
        while(True):
            #Tick framerate
            tick = self.clock.tick(FPS) / 1000.
            
            #Grab all events
            events = pygame.event.get()
            for e in events:
                if e.type == pygame.QUIT:
                    do_quit()
                elif e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        do_quit()

            #Update game objects
            self.level.update(tick, events, self.delta)
            self.interface.update(self.level.get_unit_data())
            self.render()
            
        
if __name__ == '__main__':
    main = Main()
    main.load_level('000')
    main.main()
