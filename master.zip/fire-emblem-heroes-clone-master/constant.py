#!usr/bin/env python
from const_string import *

FPS        = 60
MAX_VALUE  = 9999
NUM_SPAWN  = 4       #No. of spawning tiles
HASHLEN    = 32      #No. of chars for unique IDs
MW, MH     = 6,8     #Map dimensions       (tiles)
SW, SH     = 160,160 #Sprite dimensions    (pixels)
TW, TH     = 90,90   #Tile dimensions      (pixels)
RW, RH     = 90,90   #Rect dimensions      (pixels)
BW, BH     = 90,90   #Base tile dimensions (pixels)

#Screen size constants
TOP_H, BOT_H = 160,96
SIZE = W, H  = TW*MW, TH*MH + TOP_H + BOT_H
SCREENPOS    = SCREEN_X,SCREEN_Y = 0, TOP_H

#Sprite constants
ANIM     = 3     #Animated sprite framerate
PAD      = 2
MAPSCALE = TH/BH #Map image upscaling
DSCALE_X = 1.25  #Sprite scale upon click-and-hold
DSCALE_Y = 1.25   
SLICE    = 160   #Spritesheet tile size (pixels)
SLICE_W  = 2     #Spritesheet width     (tiles)
SLICE_H  = 1     #Spritesheet height    (tiles)

#Colors
DARKEN     = [200,200,200]
GREY       = [128,128,128]
WHITE      = [255,255,255]
RED        = [255,0,0]
BLUE       = [0,0,255]
LIGHT_RED  = [255,80,80]
LIGHT_BLUE = [80,80,255]
CLEAR      = [0,0,0,0]
ALPHA_SUB  = [0,0,0,200]

#Constant map grid
MAX_GRID = [
    [MAX_VALUE for x in range(MW)]
    for y in range(MH)
    ]

#Mouse input constants
MOUSE_DRAG   = 0.250
DOUBLE_CLICK = 0.050
DRAG_SPEED   = 6
LEFT_CLICK   = 1
RIGHT_CLICK  = 3

#Mouse click states for unit
CLICK_NULL         = 0
CLICK_BEGIN        = 1
CLICK_SELF_AT_OLD  = 2
CLICK_SELF_AT_NEW  = 3
CLICK_OTHER_AT_NEW = 4
CLICK_ENEMY        = 5

#Attack distances
RANGE = {
    KEY_MELEE:  1,
    KEY_STONE:  1,
    KEY_RANGED: 2,
    KEY_MAGIC:  2,
    KEY_HEAL1:  1,
    KEY_HEAL2:  2,
    }


#Default map data
MAP = {
    KEY_NAME:   EMPTY_STR,
    KEY_IMG:    EMPTY_STR,
    KEY_GRID:   [],
    KEY_COORDS: {
        KEY_PLAYER: [],
        KEY_ENEMY:  [],
        },         
    }

#Default unit data
UNIT = {
    #Variable/instantiated by save data
    KEY_LEVEL:  [1,],      #Unit's level
    KEY_EXP:    [0,],      #Unit's current experience points
    KEY_HP:     [0,],      #Hit points
    KEY_ATK:    [0,],      #Attack stat
    KEY_DEF:    [0,],      #Defense stat
    KEY_FRAMES: [1,],      #Number of frames for sprite
    
    #Constant across all units of this name
    KEY_NAME:  EMPTY_STR, #Unit's display name
    KEY_COLOR: EMPTY_STR, #Unit's weapon color
    KEY_TYPE:  EMPTY_STR, #Unit's weapon type
    KEY_IMG:   EMPTY_STR, #Unit's field image
    KEY_MOVES: EMPTY_STR, #Unit's movement type
    KEY_SKILL: {},        #Unit's skills (level:skill-id)
    }

#Default skill data
SKILL = {
    KEY_NAME:        EMPTY_STR, #Skill's display name
    KEY_DESCRIPTION: EMPTY_STR, #Skill's description in-game
    KEY_CONDITION:   {},        #Conditional attributes under w/c skill applies
    
    #Skill's buffs/debuffs on player
    KEY_PLAYER: {
        KEY_HP:   0, #+/- modifier to HP
        KEY_ATK:  0, #+/- modifier to Atk
        KEY_DEF:  0, #+/- modifier to Def
        KEY_DIST: 0, #Distance from unit at w/c skill applies
        },
    
    #Skill's buffs/debuffs on enemy
    KEY_ENEMY: {
        KEY_HP:   0, #+/- modifier to HP
        KEY_ATK:  0, #+/- modifier to Atk
        KEY_DEF:  0, #+/- modifier to Def
        KEY_DIST: 0, #Distance from unit at w/c skill applies
        },         
    }

#Parsing data
DATA = {
    #Maps stored in database
    KEY_MAPS:  {},
    #Units, etc. stored in savefile
    KEY_SAVES: {
        KEY_UNIT: [],
        KEY_MISC: [],
        },
    #Units stored in database
    KEY_UNIT:  {},
    #Skills stored in database
    KEY_SKILL: {},
    }

#Movement types
MOVES = {
    #Infantry
    KEY_WALK: {
        KEY_DIST:  2,
        KEY_SLOW:  [TREE,FORTRESS],
        KEY_BLOCK: [MOUNTAIN,WATER,NULL],
        KEY_NEVER: [WALL],
        },
    #Horseback
    KEY_MOUNT: {
        KEY_DIST:  3,
        KEY_SLOW:  [FORTRESS],
        KEY_BLOCK: [TREE,MOUNTAIN,WATER,NULL],
        KEY_NEVER: [WALL],
        },
    #Pegasus
    KEY_FLYING: {
        KEY_DIST:  2,
        KEY_SLOW:  [],
        KEY_BLOCK: [],
        KEY_NEVER: [WALL],
        },
    #Armored
    KEY_ARMOR: {
        KEY_DIST:  1,
        KEY_SLOW:  [TREE,FORTRESS],
        KEY_BLOCK: [MOUNTAIN,WATER,NULL],
        KEY_NEVER: [WALL],
        },
    }
