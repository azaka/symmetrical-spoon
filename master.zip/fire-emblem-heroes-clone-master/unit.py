#!usr/bin/env python
import pygame
from   pygame.locals import *
from   constant      import *
from   utility       import *

class Unit:
    def __init__(self, data, pos, isPlayer):
        #Map unit instance
        base = copy(UNIT)
        base.update(data)
        self.init_data(base, pos, isPlayer)
        self.turn_begin()

    def __eq__(self, other):
        #Method for comparing self to another Unit
        return self.id == other.id

    def __str__(self):
        #Returns string representation
        a = self.name
        b = self.moveType
        c = self.weaponType
        d = self.weaponColor

        string = 'name=%s\nmovement=%s\ntype=%s\ncolor=%s\n' %(a,b,c,d)
        return string

    def init_images(self, data, isPlayer):
        #Loads sprites from data
        imgPath = get_path(DIR_IMG, DIR_UNIT, data[KEY_IMG][0] + IMG_TYPE)
        isCpu   = not isPlayer
        frames  = int(data[KEY_FRAMES][0])
        
        #Load animated images and darkened images
        self.images    = load_images(imgPath, frames, cpu=isCpu)
        self.darks     = load_images(imgPath, frames, dark=True, cpu=isCpu)
        self.frame     = 0
        self.numFrames = len(self.images)
        self.size      = self.images[0].get_size()

    def init_constants(self):
        #Initializes values independent of unit script
        self.clickTime   = 0
        self.clickState  = CLICK_NULL
        self.isDragged   = False
        self.displayMove = False
        self.rect        = make_rect(RW, RH)

    def init_data(self, data, pos, isPlayer):
        #Local variable instantiation
        self.name        = data[KEY_NAME][0].capitalize()
        self.id          = generate_id()
        self.isPlayer    = isPlayer

        #Set up constants and unit images
        self.init_constants()
        self.init_images(data, isPlayer)
        
        #Set up temporary stat modifier containers
        self.stats = {
            'base': {
                #Raw stats (pre-modifier)
                KEY_HP:  get_stat(data[KEY_HP]),
                KEY_ATK: get_stat(data[KEY_ATK]),
                KEY_DEF: get_stat(data[KEY_DEF]),
                },
            'mods': {
                #Stat modifiers (added to raws)
                KEY_HP:  [],
                KEY_ATK: [],
                KEY_DEF: [],
                },
            }   

        #Set up skill containers and experience level
        self.skillKeys = copy(data[KEY_SKILL])
        self.skills    = {}
        self.level     = get_stat(data[KEY_LEVEL])
        self.exp       = get_stat(data[KEY_EXP])
        
        #Grid coordinates
        self.clear_move_cells()
        self.pos  = {
            'old': {'x':pos[0], 'y':pos[1]},
            'new': {'x':pos[0], 'y':pos[1]},
            'cur': {'x':pos[0], 'y':pos[1]},
            }

        self.moveType    = data[KEY_MOVES][0]
        self.weaponType  = data[KEY_TYPE][0]
        self.weaponColor = data[KEY_COLOR][0]

    def get_stat(self, statKey):
        #Quickly retrieves a current total stat of this unit
        base = self.stats['base'][statKey]
        mods = get_stat(self.stats['mods'][statKey])
        return base + mods

    def get_all(self):
        #Returns all combat data for this unit
        output = {
            KEY_NAME:   self.name,
            KEY_PLAYER: self.isPlayer,
            KEY_HP:     self.get_stat(KEY_HP),
            KEY_ATK:    self.get_stat(KEY_ATK),
            KEY_DEF:    self.get_stat(KEY_DEF),
            }
        
        return output

    def set_pos(self, key, pos):
        #Sets coordinate
        self.pos[key]['x'] = pos[0]
        self.pos[key]['y'] = pos[1]
        self.rect.topleft  = pos[0]*TW, pos[1]*TH

    def get_pos(self, key, scale=False, rounded=False):
        #Gets current coordinate as floating-point tuple
        sx,sy = (TW,TH) if scale else (1,1)
        pos   = self.pos[key]['x']*sx, self.pos[key]['y']*sy
        if rounded:
            pos = list(pos)
            func_array(pos, round, int)
            
        return tuple(pos)

    def clear_locals(self):
        #Clears player input locals
        #self.snap_to_grid()
        self.clear_move_cells()
        self.isDragged = False
        self.displayMove = False
        self.clickState = CLICK_NULL
        self.clickTime = 0

    def clear_move_cells(self):
        #Clears movement cells
        self.moveCells = []
        self.hitCells  = []
        self.displayMove = False

    def snap_to_grid(self):
        #Snap blitted sprite to grid
        pos1 = self.get_pos('new', rounded=True)
        pos2 = self.get_pos('old', rounded=True)

        #Snap movement smoothly
        a = pos1 in self.moveCells
        if a:
            self.set_pos('cur', pos1)
        else:
            self.set_pos('new', pos2)
        
    def turn_begin(self):
        #Refreshes unit's turn movement
        self.clear_locals()
        self.hasMoved = False

    def turn_end(self):
        #Ends unit's turn movement
        curPos = self.get_pos('cur', rounded=True)
        self.set_pos('old', curPos)
        self.set_pos('new', curPos)

        #Snap to grid and stop moving
        self.clear_locals()
        self.hasMoved = True
    
    def smooth_blit(self, tick, delta):
        #Smoothly blits movement between cells
        dx,dy = 0,0
        new = xNew, yNew = self.get_pos('new', scale=True, rounded=True)
        cur = xCur, yCur = self.get_pos('cur', scale=True, rounded=True)
                                
        if self.isDragged:
            #Smoothly move towards mouse pos
            xPos,yPos = pygame.mouse.get_pos()
            xPos -= TW/2 + delta[0]
            yPos -= TH/2 + delta[1]
            dx,dy = xPos-xCur, yPos-yCur
        else:
            #Get delta distance to target point
            dx,dy = xNew-xCur, yNew-yCur
            self.snap_to_grid()

        if abs(dx) + abs(dy) > 0:
            #Smoothly transition blitted sprite
            xCur += dx*tick*DRAG_SPEED
            yCur += dy*tick*DRAG_SPEED
            self.set_pos('cur', (xCur/TW,yCur/TH))
            return True
        
        #Snap to nearest cell if close enough
        self.snap_to_grid()
        return False

    def set_click_state(self, pos):
        #Sets the unit's click state
        unitPos  = pos[0] // TW, pos[1] // TH
        oldPos   = self.get_pos('old', rounded=True)
        curPos   = self.get_pos('cur', rounded=True)

        #Booleans for determining whether we're on original cell
        unitOld    = unitPos == oldPos
        clickedOld = curPos  == oldPos

        #Whether the sprite was clicked and/or a passable tile was clicked
        isClicked   = is_clicked(self.rect, pos)
        isContained = is_contained(self.moveCells, unitPos)
        
        if isClicked:
            #Simply show movement if this is an enemy unit
            if not self.isPlayer:
                self.clickState = CLICK_ENEMY
                self.displayMove = True
                return
    
            elif self.clickState == CLICK_NULL:
                #Not in focus yet, so enter focus
                self.clickState  = CLICK_BEGIN
                self.displayMove = True
                self.isDragged   = True
                
            else:
                #Clicked while at non-origin cell
                self.clickState = CLICK_SELF_AT_NEW
                    
        elif self.clickState != CLICK_NULL and isContained:
            #If a cell outside of the unit (but within move range) was clicked
            self.clickState = CLICK_OTHER_AT_NEW

        else:
            #Default: Reset to unclicked state
            self.clickState = CLICK_NULL
            self.clear_move_cells()

    def reset_pos(self):
        #Resets unit's position to beginning of turn
        newPos = self.get_pos('old', rounded=True)
        self.set_pos('new', newPos)
        self.clickTime = 0

    def process_click(self, pos, button, otherPos):
        #Event handler for mouse clicks
        if button != LEFT_CLICK:
            self.clickState = CLICK_NULL
            self.clear_move_cells()
            self.reset_pos()
            return False

        #Convert parameter position to unit coordinates of grid
        unitPos = pos[0] // TW, pos[1] // TH        
        self.set_click_state(pos)
        
        if not self.isPlayer:
            #Don't let player control enemy units
            return False
        
        if unitPos not in otherPos:
            #Process the click if it doesn't collide with other sprites
            
            if self.clickState == CLICK_OTHER_AT_NEW:
                #Click in movement range: Move to target cell
                newPos = list(unitPos)
                func_array(newPos, round, int)
                self.set_pos('new', newPos)
                return True

            if self.clickState == CLICK_SELF_AT_NEW:
                #End turn if clicked away from original cell
                self.turn_end()
                return True
        
        #Default: Return to original position if clicked outside
        self.reset_pos()
        return False

    def process_release(self, pos, button, otherPos):
        #Event handler for mouse release
        unitPos = pos[0] // TW, pos[1] // TH
        isContained = is_contained(self.moveCells, unitPos)

        if not isContained and self.clickState != CLICK_NULL:
            self.clickState = CLICK_BEGIN

        if unitPos not in otherPos:
            #Process only if mouse wasn't released over another sprite
            if self.isDragged:
                pos = self.get_pos('cur', rounded=True)
                if pos not in otherPos:
                    #If released at legal pos, set it
                    self.set_pos('new', pos)

        self.isDragged = False
        return False
            
    def process_input(self, events, delta, others):
        #Handles user input for this unit
        if self.hasMoved:
            return False
        
        mouseButton = None
        mousePos    = -1,-1
        otherPos    = [other.get_pos('old') for other in others]
        
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN:
                #Click timer's value is always low after each mouseclick
                mousePos = e.pos[0] - delta[0], e.pos[1] - delta[1]
                mouseButton = e.button
                self.process_click(mousePos, mouseButton, otherPos)
            elif e.type == pygame.MOUSEBUTTONUP:
                #Let go of mouse button
                mouseButton = e.button
                mousePos = e.pos[0] - delta[0], e.pos[1] - delta[1]
                self.process_release(mousePos, mouseButton, otherPos)
        
        return True

    def process_skills(self):
        #Checks for skill conditions met and processes as necessary
        for name, data in self.skills.items():
            #Get all skills' data sub-dictionaries
            conditions = data[KEY_CONDITION]
            bools = [True]

            for target in conditions:
                #Iterate through condition keys
                if target == KEY_PLAYER:
                    #Operate on own stats
                    for compare in conditions[target]:
                        pass
                        
    def can_display_movement(self):
        #Determines whether movement cells should be displayed
        return self.clickState != CLICK_NULL and len(self.moveCells) == 0

    def get_movement_data(self):
        #Gets unit movement calculation params
        return self.get_pos('new'), self.moveType, self.weaponType

    def get_movement(self, hitCells, moveCells):
        #Stores a list of this unit's legal move and attack cells            
        #Process local copy of map grid (only do this once!)
        self.hitCells  = hitCells
        self.moveCells = moveCells
        
    def tick(self, tick):
        #Increments time-based variables
        self.clickTime += tick
        self.tick_frames(tick)
        return True

    def tick_frames(self, tick):
        #Increments animation frames
        if self.hasMoved:
            return False
        
        self.frame += tick * ANIM
        if self.frame >= self.numFrames:
            self.frame = 0
        return True

    def render(self, surface):
        #Renders unit's sprite to screen at current blitting pos
        frame = int(self.frame)
        if self.hasMoved:
            image = self.darks[frame]
        else:
            image = self.images[frame]
            if self.isDragged:
                image = scale_rel(image, DSCALE_X, DSCALE_Y)
            
        x,y   =  self.get_pos('cur', scale=True)
        dx,dy = SW-TW, SH-TH
            
        surface.blit(image, image.get_rect(center=(x+TW/2,y+TH/2)))#(x-dx/2,y-dy/2))


    def update(self, tick, events, delta, others):
        #Update method (called once per frame)
        self.process_input(events, delta, others)
        self.process_skills()
        self.tick(tick)
        self.smooth_blit(tick, delta)
        
