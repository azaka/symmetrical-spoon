#!usr/bin/env python
import pygame, os, random
import numpy          as     np
from   pygame.locals  import *
from   constant       import *
from   copy           import deepcopy

#Utility functions

def init_display(caption=TITLE, size=SIZE):
    #Creates a rendering window
    pygame.display.set_caption(caption)
    return pygame.display.set_mode(size)

def clamp(target, minimum, maximum):
    #Restricts a variable to bounds
    return max(min(target, maximum), minimum)

def clean(lines):
    #Formats a script file into a parseable format
    return convert_lower(remove_blanks(remove_comments(lines)))

def color_image(img, col, blend=pygame.BLEND_RGB_SUB):
    #Colors an image with blending
    img = img.copy()
    col = col[:]
    
    #Invert color parameter for subtracted blendiing
    func_array(col, lambda x:-x)
    col = sum_array(WHITE, col)

    #Fill image and return it
    img.fill(col, special_flags=blend)
    return img

def convert_lower(lines):
    #Converts a script file's contents to lowercase
    return [l.lower() for l in lines]

def copy(obj):
    #Aliases deepcopy
    return deepcopy(obj)

def do_quit():
    #Safely quit game
    pygame.quit()
    raise SystemExit

def func_array(array, *funcs):
    #Applies a series of functions over each element of an array
    for func in funcs:
        for n in range(len(array)):
            array[n] = func(array[n])

def generate_id():
    #Returns a random hash ID thing
    return ''.join([random.choice(ALPHANUM) for n in range(HASHLEN)])

def get_assigns(line):
    #Gets new data values from script line
    key = split_get(line, ASSIGNS, 0).strip()
    return key

def get_block(keys, syms, line):
    #Pushes a new block onto parsing stack, or pops the last one    
    if OPENS in line:
        key = split_get(line, OPENS, 0).strip().lower()
        syms.append(OPENS)
        keys.append(key)
        return True
    
    if CLOSES in line and syms[-1] == OPENS:
        syms.pop()
        keys.pop()
        return True

    return False

def get_inputs(line):
    #Gets new data values from script line
    vals = split_get(line, ASSIGNS, 1)
    vals = vals.split(SPLITS)
    vals = [v.strip() for v in vals if len(v.strip()) != 0]
    return vals

def get_neighbors(x,y,dist=1):
    #Find orthogonal neighbors
    neighbors = []
    for n in range(-dist,dist+1):
        for m in range(-dist,dist+1):
            coord = x+m, y+n
            total = abs(n) + abs(m)
            if total > dist:
                continue
            if coord != (x,y) and coord not in neighbors:
                neighbors.append(coord)
                
    return neighbors

def get_path(*paths):
    #Fixes a relative file path given a series of dirs
    return os.path.join(DIR_RES, *paths)

def get_scaling():
    #Gets ratio between internal resolution and window
    w,h = pygame.display.get_surface().get_size()
    return W/w, H/h

def get_stat(array):
    #Gets stat from a string array out of a data dict
    return sum([int(a) for a in array])

def get_value(data, keys):
    #Recursively retrieves a nested dictionary value
    key = keys.pop()
    if len(keys) != 0:
        return get_value(data, keys)
    return data[key]

def is_clicked(rect, point):
    #Determines click collision for a rect
    sx,sy = get_scaling()
    x,y   = point[0]*sx, point[1]*sy
    return rect.collidepoint(x,y)

def is_contained(pointList, point):
    #Determines click collision in point list
    return tuple(point) in pointList

def load_image(filename, colorkey=None, sx=1, sy=1):
    #Loads image file
    if colorkey:
        img = pygame.image.load(filename).convert()
        img.set_colorkey(colorkey)
        return img
    
    img   = pygame.image.load(filename).convert_alpha()
    w,h   = img.get_size()
    scale = int(round(w*sx)), int(round(h*sy))
    img = pygame.transform.smoothscale(img, scale)
    return img

def load_images(path, frames, colorkey=None, dark=False, cpu=True):
    #Loads image file
    output   = []
    size     = SLICE,SLICE
    imCount  = 0
    filename = '%s' %(path)
    
    #Load and split image
    src     = load_image(filename, colorkey)
    yOffset = SLICE*2 if cpu else 0
    yOffset += SLICE if dark else 0

    for y in range(SLICE_H):
        for x in range(SLICE_W):
            #Get subslice of source image
            topleft = x*SLICE, y*SLICE + yOffset
            subIm   = src.subsurface(topleft,size)
            outIm = pygame.transform.scale(subIm, (SW,SH))
            output.append(outIm)

            #Tick up image count; return array if total met
            imCount += 1
            if imCount >= frames:
                return output
            
    return output

def load_units(level, data, isPlayer, *keys):
    #Adds units to a level instance
    for key in keys:
        unitData  = data[KEY_UNIT][key]
        level.load_unit(unitData, isPlayer)

def make_rect(*size):
    #Creates rect using given size
    return pygame.Rect((0,0),size)

def make_surface(*size):
    #Creates a surface using given size
    x,y = int(round(size[0])), int(round(size[1]))
    return pygame.Surface(size)

def overwrite_dict(data, key, val={}):
    #Overwrites the value of a dict entry
    data[key] = val

def palette_blend(img, blends=[255,255,255,255], flags=pygame.BLEND_RGBA_MULT):
    #Returns palette-modified copy of image
    arr = pygame.surfarray.pixels3d(img)
    arr = np.full(arr.shape, blends)#[0.298, 0.587, 0.114])
    arr = pygame.surfarray.make_surface(arr)

    img = img.copy()
    img.blit(arr, (0,0), special_flags=flags)
    
    return img

def remove_blanks(lines):
    #Quickly removes all blank lines in a script file
    return [line.strip() for line in lines if len(line.strip()) != 0]

def remove_comments(lines):
    #Removes all comments from a script file
    return [split_get(line, IGNORES, 0).strip() for line in lines]

def scale_rel(surface, sx, sy):
    #Scales an image relative to its original dimensions
    w,h = surface.get_size()
    w,h = int(round(w*sx)), int(round(h*sy))
    surface = pygame.transform.scale(surface,(w,h))
    return surface

def slice_image(surface, x, y, w, h):
    #Retrieves a subsurface from a surface
    return surface.subsurface(x, y, w, h)

def split_array(array, w, h):
    #Converts a 1D list to a 2D array (padded if necessary)
    d = max(0, w*h - len(array))
    for n in range(d):
        array.append(array[-1])

    return [array[y*w:y*w+w] for y in range(h)]

def split_get(string, delim, index):
    #Returns an element given a split string
    return string.split(delim)[index]

def sum_array(a1, a2):
    #Sums each element in an array
    length = min(len(a1), len(a2))
    a3     = [a1[n] + a2[n] for n in range(length)]
    return a3

def update_dict(data, keys, newKey, newVal):
    #Adds key:val pair to a data dictionary
    for key in keys:
        if key in data.keys():
            data = data[key]
        else:
            data.update({key:{}})
            data = data[key]

    if newKey in data.keys():
        #If key already exists, simply append new value(s)
        data[newKey] = list(data[newKey]) + newVal
        return True
    
    #If key does not exist yet, make new entry
    data.update({newKey: newVal})
    return False


