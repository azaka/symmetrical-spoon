#!usr/bin/env python
import pygame
from   pygame.locals import *
from   constant      import *
from   utility       import *

class Button:
    def __init__(self, imgFile):
        pass
