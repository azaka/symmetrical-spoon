#!usr/bin/env python

#Globally-used strings
EMPTY_STR  = ''
ALPHANUM   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwzyz0123456789!@#$%^&*()-=_+'
TITLE      = 'test'

#Map tile keys (used in script)
GROUND   = 'g'
TREE     = 't'
MOUNTAIN = 'm'
WATER    = 'a'
NULL     = 'n'
WALL     = 'w'
FORTRESS = 'f'

#Recognized file types
FILE_TYPE  = '.ocx3'
IMG_TYPE   = '.png'

#Resource directories
DIR_RES    = 'res'
DIR_DATA   = 'data'
DIR_IMG    = 'img'
DIR_UI     = 'ui'
DIR_MAPS   = 'maps'
DIR_UNIT   = 'units'

#Specific filenames for scripts
FILE_MAPS  = 'maps'   + FILE_TYPE
FILE_UNIT  = 'units'  + FILE_TYPE
FILE_SAVE  = 'save'   + FILE_TYPE
FILE_SKILL = 'skills' + FILE_TYPE

#Specific filenames for images
IMG_SPRITE = 'image'              + IMG_TYPE
IMG_SQUARE = 'square'             + IMG_TYPE
IMG_SHADOW = 'SHADOW'             + IMG_TYPE
IMG_PBAR   = 'BAR_PLAYER'         + IMG_TYPE
IMG_EBAR   = 'BAR_ENEMY'          + IMG_TYPE
IMG_VBAR1  = 'BAR_VERSUS_OVERLAY' + IMG_TYPE
IMG_VBAR2  = 'BAR_VERSUS'         + IMG_TYPE
IMG_BBAR   = 'BAR_BOTTOM'         + IMG_TYPE

#Parsing strings for script files
IGNORES  = '#'
OPENS    = '{'
CLOSES   = '}'
ASSIGNS  = ':'
SPLITS   = ','
ENDLINE  = ';'
GR_THAN  = '>'
GR_EQUAL = '>='
LS_THAN  = '<'
LS_EQUAL = '<='
EQUALS   = '=='
PLUS     = '+'
MINUS    = '-'
DIVIDE   = '/'
MULT     = '*'

#The comparison operators are intended for use in special skills,
#but they are not implemented as of yet

"""
#List of comparison operators
COMPARES = [
    GR_EQUAL,
    LS_EQUAL,
    EQUALS,
    GR_THAN,
    LS_THAN,
    ]

#List of mathematical operators
OPERATES = [
    PLUS,
    MINUS,
    DIVIDE,
    MULT,
    ]
"""

#Comprehensive collection of symbolic dictionary keys
KEY_ARMOR       = 'armored'
KEY_ATK         = 'atk'
KEY_BLOCK       = 'blocks'
KEY_BLUE        = 'blue'
KEY_CLEAR       = 'clear'
KEY_COLOR       = 'color'
KEY_CONDITION   = 'condition'
KEY_COORDS      = 'coords'
KEY_DESCRIPTION = 'description'
KEY_DEF         = 'def'
KEY_DIST        = 'dist'
KEY_ENEMY       = 'enemy'
KEY_EQUALS      = 'equals'
KEY_EXP         = 'exp'
KEY_FLYING      = 'flying'
KEY_FRAMES      = 'frames'
KEY_GREATER     = 'greater'
KEY_GREEN       = 'green'
KEY_GRID        = 'grid'
KEY_HEAL1       = 'heal-1'
KEY_HEAL2       = 'heal-2'
KEY_HP          = 'hp'
KEY_ID          = 'id'
KEY_IMG         = 'image'
KEY_LESS        = 'less'
KEY_LEVEL       = 'level'
KEY_MAGIC       = 'magic'
KEY_MAPS        = 'maps'
KEY_MELEE       = 'melee'
KEY_MISC        = 'misc'
KEY_MOUNT       = 'mounted'
KEY_MOVES       = 'movement'
KEY_NAME        = 'name'
KEY_NEVER       = 'never'
KEY_PLAYER      = 'player'
KEY_RANGED      = 'ranged'
KEY_RED         = 'red'
KEY_SAVES       = 'saved'
KEY_SKILL       = 'skill'
KEY_SLOW        = 'slows'
KEY_STONE       = 'stone'
KEY_TITLE       = 'title'
KEY_TYPE        = 'type'
KEY_UNIT        = 'unit'
KEY_WALK        = 'walking'
