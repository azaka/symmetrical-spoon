#!usr/bin/env python
import pygame
from   pygame.locals import *
from   constant      import *
from   utility       import *
from   unit          import *


def load_level(data, key):
    #Loads a map instance given its ID as key
    return Level(data[KEY_MAPS][key])

class Level:
    def __init__(self, data):
        #Unique instance of a map/level
        base = copy(MAP)
        base.update(data)
        self.init_locals()
        self.load_data(base)
        self.load_images(base)

    def init_locals(self):
        #Initialize local containers and incrementors
        self.units        = []
        self.playerAssign = 0
        self.enemyAssign  = 0
        self.recentUnit   = None

    def load_images(self, data):
        #Initialize background image
        mapPath    = get_path(DIR_IMG, DIR_MAPS, data[KEY_IMG][0])
        tilePath   = get_path(DIR_IMG, DIR_UI, IMG_SQUARE)
        shadowPath = get_path(DIR_IMG, DIR_UI, IMG_SHADOW)
        redTile    = color_image(load_image(tilePath), RED)
        blueTile   = color_image(load_image(tilePath), BLUE)
        
        #Load images for background and movement/attack cells
        self.image    = load_image(mapPath, sx=MAPSCALE, sy=MAPSCALE)
        self.redTile  = pygame.transform.scale(redTile, (TW,TH))
        self.blueTile = pygame.transform.scale(blueTile, (TW,TH))
        self.shadow   = load_image(shadowPath)

    def load_data(self, data):
        #Load data for the given level
        self.name = data[KEY_NAME][0]
        self.grid = split_array(data[KEY_GRID], MW, MH)

        #Populate player info
        self.players = split_array(data[KEY_COORDS][KEY_PLAYER], 2, NUM_SPAWN)
        for n in range(len(self.players)):
            func_array(self.players[n], int)

        #Populate enemy info
        self.enemies = split_array(data[KEY_COORDS][KEY_ENEMY], 2, NUM_SPAWN)
        for n in range(len(self.enemies)):
            func_array(self.enemies[n], int)

    def load_unit(self, unitData, isPlayer):
        #Initialize a unit instance for this level
        
        if isPlayer and self.playerAssign < NUM_SPAWN:
            #Put a player unit at the next available player spawn slot
            pos = self.players[self.playerAssign]
            self.playerAssign += 1
            
        elif not isPlayer and self.enemyAssign < NUM_SPAWN:
            #Put an enemy unit at the next available enemy spawn slot
            pos = self.enemies[self.enemyAssign]
            self.enemyAssign += 1

        #Actually instantiate the unit now
        newUnit = Unit(unitData, pos, isPlayer)
        
        self.units.append(newUnit)

    def get_grid(self, pos, moveType, weaponType, otherPos):
        #Returns a modified map grid for processing a unit's movement
        #Grabs movement distance and attack distance from templates
        moveDist   = MOVES[moveType][KEY_DIST] + 1
        attackDist = RANGE[weaponType]

        #Initialize a maxed-out Dijkstra map
        x,y      = pos
        tempGrid = copy(MAX_GRID)
        tempGrid[y][x] = 0
        hasChanged     = True

        #Output lists
        moveCells = []
        hitCells  = []

        while hasChanged:
            hasChanged = False
            
            #Iterative Dijkstra map pathfinding
            for y in range(MH):
                for x in range(MW):
                    #CHeck tile passability
                    moveSlow  = self.grid[y][x] in MOVES[moveType][KEY_SLOW]
                    moveBlock = self.grid[y][x] in MOVES[moveType][KEY_BLOCK]
                    moveNever = self.grid[y][x] in MOVES[moveType][KEY_NEVER]

                    if not (moveBlock or moveNever):
                        #Check distance passability
                        if tempGrid[y][x] + 1 < moveDist:

                            cost = 1
                            if (x,y) in otherPos and tempGrid[y][x] < moveDist:
                                #If another unit exists here
                                cost = moveDist - tempGrid[y][x] #+ 1

                            adjCells = get_neighbors(x,y)
                            for cell in adjCells:
                                #Choose all orthogonally adjacent cells
                                m, n = cell
                                
                                #Check OOB
                                xSafe = 0 <= m < MW
                                ySafe = 0 <= n < MH
                                if not (xSafe and ySafe):
                                    continue
                                
                                #Check tile passability
                                moveSlow  = self.grid[n][m] in MOVES[moveType][KEY_SLOW]
                                moveBlock = self.grid[n][m] in MOVES[moveType][KEY_BLOCK]
                                moveNever = self.grid[n][m] in MOVES[moveType][KEY_NEVER]
                                
                                #Check distance passability
                                movePass  = tempGrid[n][m] - tempGrid[y][x] >= cost+1
                                
                                if not (moveBlock or moveNever) and movePass:
                                    tempGrid[n][m] = tempGrid[y][x] + cost
                                    hasChanged = True

        for y in range(MH):
            for x in range(MW):
                #Retrieve all passable/attackable cells now
                if tempGrid[y][x] < moveDist:
                    #Within walking range
                    moveCells.append((x,y))

                    #Get attackable cells now
                    adjCells = get_neighbors(x,y,attackDist)
                    for cell in adjCells:
                        #Choose all orthogonally adjacent cells
                        m, n = cell
                        
                        #Check OOB
                        xSafe = 0 <= m < MW
                        ySafe = 0 <= n < MH
                        if not (xSafe and ySafe):
                            continue

                        #Check attack range
                        moveNever = self.grid[n][m] in MOVES[moveType][KEY_NEVER]                        
                        if not moveNever:
                            hitCells.append(cell)
                    
                   
        return list(set(hitCells)), list(set(moveCells))


    def render(self, surface):
        #Renders self to screen
        surface.blit(self.image, (0,0))

        #Always blit focused unit's sprite above others
        focusedUnit = self.get_focused_unit()
        others      = [unit for unit in self.units if unit not in focusedUnit]        
        unitList    = others + focusedUnit

        #Blit movement cells if necessary
        if len(focusedUnit) != 0:
            unit = focusedUnit[0]
            
            if unit.displayMove:
                #Draw all attack and movement cells
                for cell in unit.moveCells:
                    x,y = cell[0]*TW, cell[1]*TH
                    tile = self.blueTile if unit.isPlayer else self.redTile
                    surface.blit(tile, (x,y))
                        
                for cell in unit.hitCells:
                    if cell not in unit.moveCells:
                        x,y = cell[0]*TW, cell[1]*TH
                        surface.blit(self.redTile, (x,y))
        
        for unit in unitList:
            #Render all units in this level
            x,y   = unit.get_pos('cur', scale=True)
            dx,dy = SW-TW, SH-TH
            surface.blit(self.shadow, (x-dx/2,y-dy/2))
            unit.render(surface)

    def get_focused_unit(self):
        #Returns unit currently in click-focus
        unitList = [unit for unit in self.units if unit.clickState != CLICK_NULL]
        
        if len(unitList) != 0:
            self.recentUnit = unitList[0]
            return unitList
        return self.units

    def get_recent_unit(self):
        #Returns data from most recently clicked unit
        if self.recentUnit:
            return self.recentUnit.get_all()
        return None

    def get_unit_data(self):
        #Returns relevant data for use in GUI overlay
        output = {
            KEY_UNIT: self.get_recent_unit(),
            }
        return output

    def update(self, tick, events, delta):
        #Only update user input handling for the unit currently in focus
        focusedUnit = self.get_focused_unit()
        
        for u in self.units:
            #Iterate through all units in play and update as needed
            others = [v for v in self.units if v != u]
            
            if u in focusedUnit and u.isPlayer:
                #Update the user input click handling for units as above
                u.update(tick, events, delta, others)
            else:
                #Empty event list is passed for units not in focus
                u.update(tick, events, delta, others)
                
            if u.can_display_movement():
                #Render and populate unit's allowable movement cells
                a,b,c = u.get_movement_data()
                enemy = [
                    #Get enemy positions from other units
                    v.get_pos('old')
                    for v in self.units
                    if v.isPlayer != u.isPlayer
                    ]
                hits, moves = self.get_grid(a,b,c, enemy)
                u.get_movement(hits, moves)
