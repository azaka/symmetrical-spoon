#!usr/bin/env python
import pygame
from   pygame.locals import *
from   constant      import *
from   utility       import *

#Level state constants (referenced by GUI)


class Interface:
    def __init__(self):
        #Graphical user interface overlay
        self.init_locals()
        self.load_images()

    def init_locals(self):
        #Initialize local booleans and containers
        self.unitData = {
            KEY_NAME:   EMPTY_STR,
            KEY_PLAYER: True,
            KEY_HP:     0,
            KEY_ATK:    0,
            KEY_DEF:    0,
            }

    def load_images(self):
        #Loads GUI images
        ppath  = get_path(DIR_IMG, DIR_UI, IMG_PBAR)
        epath  = get_path(DIR_IMG, DIR_UI, IMG_EBAR)
        vpath1 = get_path(DIR_IMG, DIR_UI, IMG_VBAR1)
        vpath2 = get_path(DIR_IMG, DIR_UI, IMG_VBAR2)
        bpath  = get_path(DIR_IMG, DIR_UI, IMG_BBAR)

        #Loads status bars from above paths
        self.statPlayer    = load_image(ppath)
        self.statEnemy     = load_image(epath)
        self.statVersusTop = load_image(vpath1)
        self.statVersusBot = load_image(vpath2)
        self.statGeneral   = load_image(bpath)

    def get_data(self, data):
        #Gets specific data from unit's data passed by level
        self.unitData = data[KEY_UNIT]

    def update(self, data):
        #Gets data as passed from level instance
        self.get_data(data)

    def render(self, surface):
        #Draw to screen
        surface.blit(self.statPlayer, (0,0))

        botBar = self.statGeneral
        topBar = self.statPlayer
        if self.unitData and not self.unitData[KEY_PLAYER]:
            topBar = self.statEnemy

        #Blit status bars
        surface.blit(topBar, (0,0))
        surface.blit(botBar, botBar.get_rect(bottomleft=(0,H)))
